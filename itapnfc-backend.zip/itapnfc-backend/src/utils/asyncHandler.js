// Wraps an async route handler so any thrown error / rejected promise
// is forwarded to Express's error-handling middleware instead of crashing
// the process or hanging the request.
function asyncHandler(fn) {
  return function (req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = asyncHandler;
